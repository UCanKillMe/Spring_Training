package com.fis.bankapplication.service;

 

import java.util.List;

 

import com.fis.bankapplication.model.Transaction;

 

public interface TransService {

	public abstract List<Transaction> getAllTransOfAcc(long getAcc);

 

	public abstract String fundTransferNEFT(Transaction transaction);

 

	public abstract String fundTransferRTGS(Transaction transaction);

 

	public abstract String fundTransferIMPS(Transaction transaction);
}